package app;

public class Snippet {
	public static void main(String[] args) {
		ImageIcon
	}
}

